## Packages
framer-motion | Page transitions and UI animations
date-fns | Date formatting for blog posts
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  serif: ['"Lora"', "serif"],
  sans: ['"Inter"', "sans-serif"],
}
