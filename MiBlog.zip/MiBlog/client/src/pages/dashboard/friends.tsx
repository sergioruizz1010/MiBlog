import { useFriends } from "@/hooks/use-friends";
import { useFriendRequests } from "@/hooks/use-friend-requests";
import { AddFriendDialog } from "@/components/AddFriendDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { UserCheck, UserPlus, X } from "lucide-react";

export default function FriendsPage() {
  const { data: friends, isLoading: isLoadingFriends, error: friendsError } = useFriends();
  const { requests, isLoading: isLoadingRequests, updateRequest } = useFriendRequests();

  if (isLoadingFriends || isLoadingRequests) return <FriendsLoading />;
  if (friendsError) return <div className="text-destructive">Failed to load friends</div>;

  const pendingRequests = requests?.filter(r => r.status === 'pending') || [];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">Friends</h1>
          <p className="text-muted-foreground mt-1">Connect with people you know.</p>
        </div>
        <AddFriendDialog />
      </div>

      {pendingRequests.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-serif font-bold flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-primary" />
            Friend Requests
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingRequests.map((request) => (
              <Card key={request.id} className="p-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={request.fromUser.profileImageUrl || undefined} />
                    <AvatarFallback>{request.fromUser.firstName?.[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-bold">{request.fromUser.firstName} {request.fromUser.lastName}</p>
                    <p className="text-xs text-muted-foreground">{request.fromUser.email}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    variant="default"
                    onClick={() => updateRequest({ id: request.id, status: 'accepted' })}
                  >
                    Accept
                  </Button>
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={() => updateRequest({ id: request.id, status: 'rejected' })}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      <section className="space-y-4">
        <h2 className="text-xl font-serif font-bold flex items-center gap-2">
          <UserCheck className="h-5 w-5 text-primary" />
          My Friends
        </h2>
        {!friends || friends.length === 0 ? (
          <div className="text-center py-20 bg-muted/30 rounded-2xl border border-dashed border-border">
            <h3 className="text-xl font-medium text-foreground mb-2">No friends yet</h3>
            <p className="text-muted-foreground mb-6">Start building your network by adding friends.</p>
            <AddFriendDialog />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {friends.map((friend, index) => (
              <motion.div
                key={friend.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="p-6 flex items-center gap-4 hover-elevate transition-all duration-300">
                  <Avatar className="h-16 w-16 border-2 border-background shadow-sm">
                    <AvatarImage src={friend.profileImageUrl || undefined} />
                    <AvatarFallback className="text-lg bg-primary/10 text-primary font-bold">
                      {friend.firstName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-bold text-lg">{friend.firstName} {friend.lastName}</h3>
                    <p className="text-sm text-muted-foreground truncate max-w-[180px]">
                      {friend.email}
                    </p>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function FriendsLoading() {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div className="space-y-2">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-4 w-48" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-6 flex items-center gap-4">
            <Skeleton className="h-16 w-16 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="h-4 w-40" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
