import { usePosts } from "@/hooks/use-posts";
import { useFriendsBlogs } from "@/hooks/use-friends-blogs";
import { useAuth } from "@/hooks/use-auth";
import { useFriends } from "@/hooks/use-friends";
import { useFriendRequests } from "@/hooks/use-friend-requests";
import { CreatePostDialog } from "@/components/CreatePostDialog";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { Clock, Users, UserPlus, UserCheck, Globe, Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/lib/supabase";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export default function BlogsPage() {
  const { user: currentUser } = useAuth();
  const { data: localPosts, isLoading: localLoading, error: localError } = usePosts();
  const { data: supabasePosts, isLoading: supabaseLoading, error: supabaseError } = useQuery({
    queryKey: ['supabase-blogs', currentUser?.id],
    queryFn: async () => {
      // IDs de amigos
      const { data: friends } = await supabase.from('friends').select('friend_id').eq('user_id', currentUser?.id);
      const friendIds = friends?.map(f => f.friend_id) || [];

      // Blogs de amigos + perfiles públicos
      const { data: blogs } = await supabase
        .from('blogs')
        .select('*, users(email,is_public)')
        .or(`user_id.in.(${friendIds.length > 0 ? friendIds.join(',') : currentUser?.id}),users.is_public.eq.true`)
        .order('created_at', { ascending: false });

      return blogs;
    },
    enabled: !!currentUser
  });
  const { data: friends } = useFriends();
  const { requests, sendRequest } = useFriendRequests();

  // Fetch all public users to show in "Discover"
  const { data: allUsers, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["supabase-users"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('users')
        .select('*');
      if (error) throw error;
      return data as User[];
    }
  });

  const isLoading = localLoading || supabaseLoading || isLoadingUsers;
  const error = localError || supabaseError;

  const isFriend = (userId: string) => friends?.some(f => f.id === userId);
  const hasPendingRequest = (userId: string) => requests?.some(r => r.toUserId === userId && r.status === 'pending');

  // Combine and sort posts by date
  const combinedPosts = [
    ...(localPosts || []).map(p => ({ 
      ...p, 
      source: 'local',
      isFriend: false 
    })),
    ...(supabasePosts || []).map(p => {
      const isFriendPost = p.users?.is_public === false || (p.users?.email && p.users.email !== ''); 
      return { 
        id: p.id, 
        title: p.title, 
        content: p.content, 
        authorId: p.users?.email || p.user_id, 
        createdAt: p.created_at,
        source: 'supabase',
        isFriend: !!isFriendPost 
      };
    })
  ].sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());

  if (isLoading) return <BlogsLoading />;
  if (error) return <div className="text-destructive">Failed to load blogs</div>;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">Community Blogs</h1>
          <p className="text-muted-foreground mt-1">Explore stories from the community and your network.</p>
        </div>
        <CreatePostDialog />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-serif font-bold">Recent Stories</h2>
          {combinedPosts.length === 0 ? (
            <div className="text-center py-20 bg-muted/30 rounded-2xl border border-dashed border-border">
              <h3 className="text-xl font-medium text-foreground mb-2">No posts yet</h3>
              <p className="text-muted-foreground mb-6">Be the first to share your story!</p>
              <CreatePostDialog />
            </div>
          ) : (
            <div className="grid gap-6">
              {combinedPosts.map((post, index) => (
                <motion.div
                  key={`${post.source}-${post.id}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="group hover-elevate transition-all duration-300 border-border/60">
                    <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0">
                      <CardTitle className="font-serif text-2xl leading-tight group-hover:text-primary transition-colors">
                        {post.title}
                      </CardTitle>
                      {post.source === 'supabase' && (
                        <Badge variant={post.isFriend ? "secondary" : "outline"} className="flex items-center gap-1">
                          {post.isFriend ? <Users className="h-3 w-3" /> : null}
                          {post.isFriend ? "Friend" : "Public"}
                        </Badge>
                      )}
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground leading-relaxed line-clamp-3">
                        {post.content}
                      </p>
                    </CardContent>
                    <CardFooter className="border-t border-border/50 pt-4 flex justify-between items-center text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">
                        {post.source === 'supabase' ? `By ${post.authorId}` : 'You'}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5" />
                        {post.createdAt && format(new Date(post.createdAt), "MMM d, yyyy")}
                      </div>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <h2 className="text-xl font-serif font-bold">Discover People</h2>
          <Card className="divide-y overflow-hidden">
            {allUsers?.filter(u => u.id !== currentUser?.id).map((user) => (
              <div key={user.id} className="p-4 flex items-center justify-between gap-4 hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={user.profileImageUrl || undefined} />
                    <AvatarFallback className="bg-primary/10 text-primary">{user.firstName?.[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col min-w-0">
                    <span className="text-sm font-medium truncate">{user.firstName} {user.lastName}</span>
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      {user.isPublic ? <><Globe className="h-2 w-2" /> Public</> : <><Lock className="h-2 w-2" /> Private</>}
                    </div>
                  </div>
                </div>
                {isFriend(user.id) ? (
                  <Badge variant="secondary" className="h-8">
                    <UserCheck className="h-3.5 w-3.5 mr-1" />
                    Friend
                  </Badge>
                ) : (
                  <Button 
                    size="sm" 
                    variant={hasPendingRequest(user.id) ? "outline" : "default"}
                    disabled={hasPendingRequest(user.id)}
                    className="h-8 px-3"
                    onClick={() => sendRequest(user.id)}
                  >
                    {hasPendingRequest(user.id) ? "Pending" : <><UserPlus className="h-3.5 w-3.5 mr-1" /> Add</>}
                  </Button>
                )}
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}

function BlogsLoading() {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div className="space-y-2">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-64" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>
      <div className="space-y-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-6 space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-20 w-full" />
            <div className="flex justify-between pt-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
