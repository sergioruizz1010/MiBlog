import { useAuth } from "@/hooks/use-auth";
import { useUserStats } from "@/hooks/use-user-stats";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BookOpen, Users, Globe, Lock } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { supabase } from "@/lib/supabase";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function ProfilePage() {
  const { user } = useAuth();
  const { data: stats, isLoading } = useUserStats();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  if (!user) return null;

  const handleTogglePublic = async (checked: boolean) => {
    const { error } = await supabase
      .from('users')
      .update({ is_public: checked })
      .eq('id', user.id);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to update profile visibility.",
        variant: "destructive",
      });
      return;
    }

    // Update local cache
    queryClient.setQueryData(["/api/auth/user"], { ...user, isPublic: checked });
    
    toast({
      title: "Success",
      description: `Your profile is now ${checked ? 'public' : 'private'}.`,
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-serif font-bold text-foreground">Profile</h1>
        <p className="text-muted-foreground mt-1">Manage your account and view your activity.</p>
      </div>

      <div className="grid gap-8 md:grid-cols-[1fr_2fr]">
        {/* User Card */}
        <div className="space-y-6">
          <Card className="shadow-sm overflow-hidden">
            <div className="h-32 bg-gradient-to-r from-primary/20 to-primary/5" />
            <div className="px-6 pb-6 relative">
              <Avatar className="h-24 w-24 border-4 border-background absolute -top-12 shadow-lg">
                <AvatarImage src={user.profileImageUrl || undefined} />
                <AvatarFallback className="text-3xl bg-primary/10 text-primary font-bold">
                  {user.firstName?.[0]}
                </AvatarFallback>
              </Avatar>
              <div className="mt-16 space-y-1">
                <h2 className="text-2xl font-bold font-serif">{user.firstName} {user.lastName}</h2>
                <p className="text-muted-foreground">{user.email}</p>
              </div>
            </div>
          </Card>

          {/* Privacy Settings */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <Label htmlFor="public-profile" className="text-base font-semibold">Public Profile</Label>
                  {user.isPublic ? (
                    <Globe className="h-3.5 w-3.5 text-primary" />
                  ) : (
                    <Lock className="h-3.5 w-3.5 text-muted-foreground" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  Allow everyone to see your posts in the community feed.
                </p>
              </div>
              <Switch
                id="public-profile"
                checked={user.isPublic ?? true}
                onCheckedChange={handleTogglePublic}
              />
            </div>
          </Card>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 h-fit">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Posts</CardTitle>
              <BookOpen className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-3xl font-bold">{stats?.postCount || 0}</div>
              )}
              <p className="text-xs text-muted-foreground mt-1">Published blogs</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Friends</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-3xl font-bold">{stats?.friendCount || 0}</div>
              )}
              <p className="text-xs text-muted-foreground mt-1">Connected users</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
