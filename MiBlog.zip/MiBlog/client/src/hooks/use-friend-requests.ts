import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { FriendRequest, User } from "@shared/schema";

export function useFriendRequests() {
  const { toast } = useToast();

  const requestsQuery = useQuery({
    queryKey: [api.friendRequests.list.path],
  });

  const sendMutation = useMutation({
    mutationFn: async (toUserId: string) => {
      const res = await apiRequest("POST", api.friendRequests.send.path, { toUserId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.friendRequests.list.path] });
      toast({ title: "Success", description: "Friend request sent!" });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string, status: 'accepted' | 'rejected' }) => {
      const res = await apiRequest("PATCH", buildUrl(api.friendRequests.update.path, { id }), { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.friendRequests.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.friends.list.path] });
      toast({ title: "Success", description: "Friend request updated!" });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error", 
        description: error.message,
        variant: "destructive"
      });
    }
  });

  return {
    requests: requestsQuery.data as (FriendRequest & { fromUser: User })[] | undefined,
    isLoading: requestsQuery.isLoading,
    sendRequest: sendMutation.mutate,
    isSending: sendMutation.isPending,
    updateRequest: updateMutation.mutate,
    isUpdating: updateMutation.isPending,
  };
}
