import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useFriends() {
  return useQuery({
    queryKey: [api.friends.list.path],
    queryFn: async () => {
      const res = await fetch(api.friends.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch friends");
      return api.friends.list.responses[200].parse(await res.json());
    },
  });
}

export function useAddFriend() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (email: string) => {
      const res = await fetch(api.friends.add.path, {
        method: api.friends.add.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 404) {
          throw new Error("User not found with that email");
        }
        if (res.status === 400) {
           const error = api.friends.add.responses[400].parse(await res.json());
           throw new Error(error.message);
        }
        throw new Error("Failed to add friend");
      }
      
      return api.friends.add.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.friends.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.users.stats.path] });
      toast({
        title: "Friend Added",
        description: "You have successfully connected.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
