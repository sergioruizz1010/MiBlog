import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/use-auth";

export function useFriendsBlogs() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["/api/supabase/friends-blogs", user?.id],
    queryFn: async () => {
      if (!user) return [];

      // Fetch friend IDs from local API
      const res = await fetch("/api/friends", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch friends for Supabase query");
      const friends = await res.json();
      
      const friendIds = friends.map((f: any) => f.id);
      
      let query = supabase
        .from('blogs')
        .select('*, users(email, is_public)');

      // Query blogs that are public OR belong to friends
      const { data, error } = await supabase
        .from('blogs')
        .select('*, users(email, is_public)')
        .or(`user_id.eq.${friendIds.join(',')},users.is_public.eq.true`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });
}
