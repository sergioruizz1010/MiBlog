# MiBlog

## Overview

MiBlog is a minimalist blogging and social platform where users can write and share blog posts, connect with friends, and manage their profile. The application features a clean, modern UI with authentication via Replit Auth, a PostgreSQL database for persistence, and a React frontend with an Express backend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Forms**: React Hook Form with Zod validation
- **Animations**: Framer Motion for page transitions and UI animations
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Authentication**: Replit Auth (OpenID Connect) with Passport.js
- **Session Management**: express-session with connect-pg-simple for PostgreSQL session storage
- **API Design**: RESTful endpoints defined in shared routes with Zod schemas for type safety

### Data Storage
- **Database**: PostgreSQL
- **Schema Location**: `shared/schema.ts` and `shared/models/auth.ts`
- **Key Tables**:
  - `users`: User accounts (managed by Replit Auth)
  - `sessions`: Session storage for authentication
  - `posts`: Blog posts with title, content, and author reference
  - `friends`: Friend relationships between users
- **Migrations**: Drizzle Kit with `db:push` command

### Authentication & Authorization
- **Provider**: Replit Auth (OpenID Connect)
- **Session Storage**: PostgreSQL via connect-pg-simple
- **Protected Routes**: Middleware `isAuthenticated` guards API endpoints
- **User Flow**: Login redirects to `/api/login`, logout via `/api/logout`

### Project Structure
```
├── client/              # Frontend React application
│   └── src/
│       ├── components/  # UI components including shadcn/ui
│       ├── hooks/       # Custom React hooks (auth, posts, friends)
│       ├── pages/       # Page components (landing, dashboard)
│       └── lib/         # Utilities and query client
├── server/              # Backend Express application
│   ├── replit_integrations/  # Replit Auth integration
│   ├── routes.ts        # API route handlers
│   └── storage.ts       # Database operations
├── shared/              # Shared code between client and server
│   ├── schema.ts        # Drizzle database schema
│   ├── routes.ts        # API route definitions with Zod
│   └── models/          # Type definitions
└── migrations/          # Database migrations
```

### API Structure
Routes are defined in `shared/routes.ts` with Zod schemas for input validation and response typing:
- `GET /api/posts` - List user's posts
- `POST /api/posts` - Create a new post
- `GET /api/friends` - List user's friends
- `POST /api/friends` - Add a friend by email
- `GET /api/users/stats` - Get user statistics

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management

### Authentication
- **Replit Auth**: OpenID Connect provider for user authentication
- **Required Environment Variables**:
  - `DATABASE_URL`: PostgreSQL connection string
  - `SESSION_SECRET`: Secret for session encryption
  - `ISSUER_URL`: Replit OIDC issuer (defaults to https://replit.com/oidc)
  - `REPL_ID`: Replit application identifier

### Third-Party Services
- **Supabase**: Client configured in `client/src/lib/supabase.ts` (requires `VITE_SUPABASE_KEY` environment variable)

### Key NPM Packages
- **Frontend**: React, TanStack Query, Wouter, Framer Motion, shadcn/ui components, React Hook Form
- **Backend**: Express, Passport, Drizzle ORM, express-session, connect-pg-simple
- **Shared**: Zod for validation, date-fns for date formatting