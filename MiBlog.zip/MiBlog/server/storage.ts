import { posts, friends, users, friendRequests, type Post, type InsertPost, type Friend, type FriendRequest, type InsertFriendRequest } from "@shared/schema";
import { db } from "./db";
import { eq, count, inArray } from "drizzle-orm";

export interface IStorage {
  getPostsByAuthor(authorId: string): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  getFriends(userId: string): Promise<Friend[]>;
  addFriend(userId: string, friendId: string): Promise<Friend>;
  getUserStats(userId: string): Promise<{ postCount: number, friendCount: number }>;
  getUserByEmail(email: string): Promise<typeof users.$inferSelect | undefined>;
  getUsersByIds(ids: string[]): Promise<typeof users.$inferSelect[]>;
  getFriendRequests(userId: string): Promise<(FriendRequest & { fromUser: typeof users.$inferSelect })[]>;
  createFriendRequest(request: InsertFriendRequest): Promise<FriendRequest>;
  updateFriendRequest(id: string, status: string): Promise<FriendRequest | undefined>;
  seed(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getPostsByAuthor(authorId: string): Promise<Post[]> {
    return await db.select().from(posts).where(eq(posts.authorId, authorId));
  }

  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db.insert(posts).values(post).returning();
    return newPost;
  }

  async getFriends(userId: string): Promise<Friend[]> {
    return await db.select().from(friends).where(eq(friends.userId, userId));
  }

  async addFriend(userId: string, friendId: string): Promise<Friend> {
    const [newFriend] = await db.insert(friends).values({ userId, friendId }).returning();
    return newFriend;
  }

  async getUserStats(userId: string): Promise<{ postCount: number, friendCount: number }> {
    const [postCountRes] = await db.select({ count: count() }).from(posts).where(eq(posts.authorId, userId));
    const [friendCountRes] = await db.select({ count: count() }).from(friends).where(eq(friends.userId, userId));
    return {
      postCount: postCountRes?.count ?? 0,
      friendCount: friendCountRes?.count ?? 0
    };
  }

  async getUserByEmail(email: string) {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUsersByIds(ids: string[]) {
    if (ids.length === 0) return [];
    return await db.select().from(users).where(inArray(users.id, ids));
  }

  async getFriendRequests(userId: string) {
    const results = await db.query.friendRequests.findMany({
      where: eq(friendRequests.toUserId, userId),
      with: { fromUser: true },
    });
    return results;
  }

  async createFriendRequest(request: InsertFriendRequest) {
    const [newRequest] = await db.insert(friendRequests).values(request).returning();
    return newRequest;
  }

  async updateFriendRequest(id: string, status: string) {
    const [updated] = await db.update(friendRequests)
      .set({ status })
      .where(eq(friendRequests.id, id))
      .returning();
    
    if (updated && status === 'accepted') {
      // Create friendship records in both directions
      await db.insert(friends).values([
        { userId: updated.fromUserId, friendId: updated.toUserId },
        { userId: updated.toUserId, friendId: updated.fromUserId }
      ]);
    }
    
    return updated;
  }

  async seed() {
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) return;

    const demoUserId = "demo-user-id";
    await db.insert(users).values({
        id: demoUserId,
        email: "demo@example.com",
        firstName: "Demo",
        lastName: "User",
    }).onConflictDoNothing();

    await db.insert(posts).values([
        {
            title: "Welcome to your new blog!",
            content: "This is a sample post. You can create your own posts in the 'Blogs' section.",
            authorId: demoUserId
        },
        {
            title: "Getting Started",
            content: "Connect with friends and share your thoughts.",
            authorId: demoUserId
        }
    ]);
  }
}

export const storage = new DatabaseStorage();
