import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { api } from "@shared/routes";
import { z } from "zod";
import { isAuthenticated } from "./replit_integrations/auth";
import { friendRequests } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // Seed data
  await storage.seed();

  // Protected routes
  app.get(api.posts.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const posts = await storage.getPostsByAuthor(userId);
    res.json(posts);
  });

  app.post(api.posts.create.path, isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const input = api.posts.create.input.parse(req.body);
      const post = await storage.createPost({ ...input, authorId: userId });
      res.status(201).json(post);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.friends.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const friendsRel = await storage.getFriends(userId);
    const friendIds = friendsRel.map(f => f.friendId);
    const friends = await storage.getUsersByIds(friendIds);
    res.json(friends);
  });

  app.post(api.friends.add.path, isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const { email } = api.friends.add.input.parse(req.body);

      const friendUser = await storage.getUserByEmail(email);
      if (!friendUser) {
        return res.status(404).json({ message: "User not found" });
      }
      if (friendUser.id === userId) {
        return res.status(400).json({ message: "Cannot add yourself" });
      }

      const newFriend = await storage.addFriend(userId, friendUser.id);
      res.status(201).json(newFriend);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.users.stats.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const stats = await storage.getUserStats(userId);
    res.json(stats);
  });

  app.get(api.friendRequests.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const requests = await storage.getFriendRequests(userId);
    res.json(requests);
  });

  app.post(api.friendRequests.send.path, isAuthenticated, async (req, res) => {
    try {
      const fromUserId = (req.user as any).claims.sub;
      const { toUserId } = api.friendRequests.send.input.parse(req.body);
      
      if (fromUserId === toUserId) {
        return res.status(400).json({ message: "Cannot send request to yourself" });
      }

      const request = await storage.createFriendRequest({ fromUserId, toUserId });
      res.status(201).json(request);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.patch(api.friendRequests.update.path, isAuthenticated, async (req, res) => {
    try {
      const { status } = api.friendRequests.update.input.parse(req.body);
      const request = await storage.updateFriendRequest(req.params.id, status);
      if (!request) {
        return res.status(404).json({ message: "Friend request not found" });
      }
      res.json(request);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  return httpServer;
}
