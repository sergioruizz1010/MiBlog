import { z } from 'zod';
import { insertPostSchema, posts, friends, users } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  posts: {
    list: {
      method: 'GET' as const,
      path: '/api/posts',
      responses: {
        200: z.array(z.custom<typeof posts.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/posts',
      input: insertPostSchema.omit({ authorId: true }),
      responses: {
        201: z.custom<typeof posts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  friends: {
    list: {
      method: 'GET' as const,
      path: '/api/friends',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
    add: {
      method: 'POST' as const,
      path: '/api/friends',
      input: z.object({ email: z.string().email() }),
      responses: {
        201: z.custom<typeof friends.$inferSelect>(),
        404: errorSchemas.notFound,
        400: errorSchemas.validation,
      },
    }
  },
  users: {
    stats: {
        method: 'GET' as const,
        path: '/api/user/stats',
        responses: {
            200: z.object({
                postCount: z.number(),
                friendCount: z.number()
            })
        }
    }
  },
  friendRequests: {
    list: {
      method: 'GET' as const,
      path: '/api/friend-requests',
      responses: {
        200: z.array(z.custom<typeof friendRequests.$inferSelect & { fromUser: typeof users.$inferSelect }>()),
      },
    },
    send: {
      method: 'POST' as const,
      path: '/api/friend-requests',
      input: z.object({ toUserId: z.string() }),
      responses: {
        201: z.custom<typeof friendRequests.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/friend-requests/:id',
      input: z.object({ status: z.enum(['accepted', 'rejected']) }),
      responses: {
        200: z.custom<typeof friendRequests.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
